#include "stdafx.h"
#include "BitMasking.h"
#include <wtypes.h>
#include <iostream>
int _tmain(int argc, _TCHAR* argv[])
{
	BYTE  nVal = 3;
	CBitMasking mask(nVal);
	std::cout << "\nInitial value is:";
	mask.Display();
	CBitMasking::Bits bit2 = CBitMasking::Bit2;
	
	//clearing second bit
	mask.ClearBit(bit2);
	std::cout << "\nAfter clearing second bit:";
	mask.Display();

	//checking bit2 is on or off
	if(mask.CheckBit(bit2))
	    std::cout << "\nsecond bit is on";
	else
		std::cout << "\nsecond bit is off";


	CBitMasking::Bits bit4 = CBitMasking::Bit4;
	//turn on fourth bit
	mask.SetBit(bit4);
	std::cout << "\nAfter setting fourth bit on:";
	mask.Display();

	//turn on fourth bit
	mask.ToggleBit(bit4);
	std::cout << "\nAfter toggling fourth bit ";
	mask.Display();

	return 0;
}