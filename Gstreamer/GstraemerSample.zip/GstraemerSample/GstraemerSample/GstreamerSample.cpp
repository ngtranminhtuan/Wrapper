// GstraemerSample.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "GStreamerImpl.h"
#include "GstreamerEventListener.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Streaming::CGstreamerImpl* m_pStreamer = new Streaming::CGstreamerImpl();
	m_pStreamer->AddStreamEventListener(new CGstreamerEventListener());
	m_pStreamer->Init(0, NULL);	
	m_pStreamer->Load("file:///D:/PELCO/Gstreamer-1.0/1.0/x86_64/bin/1.mp4");
	m_pStreamer->Play();
	return 0;
}

