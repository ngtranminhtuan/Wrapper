#include "IStreamer.h"
class CGstreamerEventListener : public Streaming::IStreamEventListener
{


public:
	CGstreamerEventListener();
	virtual void OnError();

	virtual void OnVedeoStarted();

	virtual void OnVedeoStopped();

	virtual void OnReachedEndofStream();

	virtual void OnVedeoPaused();

	virtual void OnRefreshGUI();

	virtual void OnVedeoResume();

};