#include "stdafx.h"
#include "GstreamerEventListener.h"
#include <iostream>

using namespace std;
CGstreamerEventListener::CGstreamerEventListener()
{
	
}

void CGstreamerEventListener::OnError()
{
	cout << "\nStream Error occurred";
}

void CGstreamerEventListener::OnVedeoStarted()
{
	cout << "\nVideo Started";
}

void CGstreamerEventListener::OnVedeoStopped()
{
	cout << "\nVideo Stopped";
}

void CGstreamerEventListener::OnReachedEndofStream()
{
	cout << "\nEnd of stream reached";
}

void CGstreamerEventListener::OnVedeoPaused()
{
	cout << "\video paused ";
}

void CGstreamerEventListener::OnRefreshGUI()
{
	cout << "\nUi refreshed ";
}

void CGstreamerEventListener::OnVedeoResume()
{
	cout << "\n OnVedeo Resume ";
}

