//
// Timer handler class
//

#ifndef MYAPPLICATION_CTIMERTEST_H
#define MYAPPLICATION_CTIMERTEST_H

class CTimerTest
{
public:
    void OnStart();
    void OnStop();
    void OnTimeOut();

    void Test();
};
#endif //MYAPPLICATION_CTIMERTEST_H
